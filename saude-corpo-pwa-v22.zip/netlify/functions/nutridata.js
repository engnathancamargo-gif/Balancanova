// Proxy server-side para a API NutriData. A chave é recebida no header e nunca registrada.
exports.handler = async (event) => {
  const headers = {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store"
  };
  if (event.httpMethod !== "GET") {
    return { statusCode: 405, headers, body: JSON.stringify({ success: false, error: "Método não permitido." }) };
  }
  const key = event.headers["x-api-key"] || event.headers["X-API-Key"];
  if (!key || !/^nd_[A-Za-z0-9_-]{20,}$/.test(key)) {
    return { statusCode: 401, headers, body: JSON.stringify({ success: false, error: "Chave NutriData ausente ou inválida." }) };
  }
  const rawPath = event.queryStringParameters && event.queryStringParameters.path;
  if (!rawPath || !/^\/foods\/[A-Za-z0-9/?=&%._-]+$/.test(rawPath)) {
    return { statusCode: 400, headers, body: JSON.stringify({ success: false, error: "Caminho de consulta inválido." }) };
  }
  try {
    const upstream = await fetch("https://api.nutritrack.me/api/v1" + rawPath, {
      method: "GET",
      headers: { "X-API-Key": key, "Accept": "application/json" },
      redirect: "error"
    });
    const body = await upstream.text();
    return { statusCode: upstream.status, headers, body };
  } catch (err) {
    return { statusCode: 502, headers, body: JSON.stringify({ success: false, error: "Falha ao consultar a API NutriData pelo servidor.", detail: String(err && err.message || err) }) };
  }
};
